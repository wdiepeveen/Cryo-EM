from experiments.primal_dual_volume_and_rotation_reconstruction import run_experiment

if __name__ == '__main__':
    run_experiment()